os.pullEvent = os.pullEventRaw
if not fs.exists("/khhs/jimmos/shadow") then
  shell.run("/khhs/jimmos/setup/install.lua")
end
term.clear()
term.setCursorPos(1, 1)
print("Booting JimmOS 0.1")
term.write("Username: ")
local user = io.read("*l")
term.write("Password: ")
local pass = io.read("*l")

local file = fs.open("/khhs/jimmos/shadow", "r")
local f_user = file.readLine()

if user ~= f_user then
  printError("Invalid username!")
  shell.run("shutdown")
end
if pass ~= file.readLine() then
  printError("Invalid password!")
  shell.run("shutdown")
end
print("Welcome " .. user .. "!")
