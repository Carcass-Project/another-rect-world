os.pullEvent = os.pullEventRaw
if not fs.exists("/khhs/auther/shadow") then
  shell.run("/khhs/auther/setup/install.lua")
end
term.clear()
term.setCursorPos(1, 1)
print("Booting with auther")
term.write("Username: ")
local user = io.read("*l")
term.write("Password: ")
local pass = io.read("*l")

local file = fs.open("/khhs/auther/shadow", "r")
local f_user = file.readLine()

if user ~= f_user then
  printError("Invalid username!")
  shell.run("shutdown")
end
if pass ~= file.readLine() then
  printError("Invalid password!")
  shell.run("shutdown")
end
term.clear()
term.setCursorPos(0, 0)
print("Welcome " .. user .. "!")
