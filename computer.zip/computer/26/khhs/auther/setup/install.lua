os.pullEvent = os.pullEventRaw
term.clear()
local w, h = term.getSize()
paintutils.drawBox(1, 1, w, h, colors.white)
paintutils.drawFilledBox(2, 2, w - 1, h - 1, colors.blue)
term.setCursorBlink(false)
term.setCursorPos(3, 3)
term.write("Installing auther")
term.setCursorPos(3, 4)
term.write("Please enter a username: ")
local username = io.read("*l")
term.setCursorPos(3, 5)
term.write("Please enter a password: ")
local password = io.read("*l")
term.setCursorPos(3, 15)
term.write("Press enter to continue")
io.read("*l")
term.setBackgroundColor(colors.black)
term.clear()
term.setCursorPos(1, 1)
print("Writing shadow file")
local file = fs.open("/khhs/auther/shadow", "w")
if file then
  file.write(username .. "\n" .. password)
  print("Created shadow file!")
else
  print("Writing to shadow file failed!")
end
file.close()
file = fs.open("startup", "w")
if file then
  file.write("shell.run(\"/khhs/auther/main.lua\")")
else
  print("Unable to set auther as startup!")
end
file.close()
disk.eject("right")
shell.run("reboot")
