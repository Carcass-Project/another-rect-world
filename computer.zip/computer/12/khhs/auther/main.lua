os.pullEvent = os.pullEventRaw
if not fs.exists("/khhs/auther/shadow") then
  shell.run("/khhs/auther/setup/install.lua")
end
term.clear()
local w, h = term.getSize()
paintutils.drawBox(1, 1, w, h, colors.white)
paintutils.drawFilledBox(2, 2, w - 1, h - 1, colors.blue)
term.setCursorPos(w / 2 - 10, h / 2 - 1)
term.write("Username: ")
local user = io.read("*l")
term.setCursorPos(w / 2 - 10, h / 2 + 1)
term.write("Password: ")
local pass = io.read("*l")

local file = fs.open("/khhs/auther/shadow", "r")
local f_user = file.readLine()
paintutils.drawFilledBox(1, 1, w, h, colors.black)
term.clear()
if user ~= f_user then
  printError("Invalid username!")
  shell.run("shutdown")
end
if pass ~= file.readLine() then
  printError("Invalid password!")
  shell.run("shutdown")
end
term.clear()
term.setCursorPos(0, 0)
print("Welcome " .. user .. "!")
shell.run("/khhs/auther/login")
