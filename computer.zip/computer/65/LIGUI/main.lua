function startup()
  local w, h = term.getSize()
 
  term.setCursorPos(w/2-10/2,h/2)
  textutils.slowPrint("LIGUI v0.1",120)
  os.pullEvent()
  drawGui()
  os.pullEvent()
end

function drawGui()
  local w, h = term.getSize()
  term.clear()
  paintutils.drawBox(1,1,w,h,colors.white)
  paintutils.drawFilledBox(2,2,w-1,h-1,colors.lightBlue)
end

startup()
